describe('Basic test', () => {
  const text = 'hello';

  it('should work', () => {
    expect(text).toBe('hello');
  });
});
